#pragma once

#include "Printer.h"

class Hexazecimal : public Printer{
public:
    std::string GetFormatName();
    std::string FormatNumber(int number);
};